# Blank python file to pop up a terminal, then close
'''from time import sleep
import random

sleep(random.randint(1,10) / 10)'''